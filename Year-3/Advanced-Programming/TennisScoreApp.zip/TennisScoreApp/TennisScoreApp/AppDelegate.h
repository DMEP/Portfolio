//
//  AppDelegate.h
//  TennisScoreApp
//
//  Created by Daniel Elstob on 05/05/2014.
//  Copyright (c) 2014 Daniel Elstob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
